/* Solution to the "Meep meep!" Facebook puzzle
 * By: Lincoln Simmons
 * Date: March 3, 2011
 */

#include <stdio.h>

int main (void)
{
	printf("Meep meep!\n");
	return 0;
}
